#Dan Miller Runfola
#dan@danrunfola.com | drunfola@aiddata.org
#Script takes in x,y location of aid projects
#Stack of arbitrary rasters
#Aggregates to any arbitrary polygone for analysis
#Outputs a Decision Tree MLA for various outcomes

library(sp)
library(maptools)
library(plyr)
library(raster)
library(rgdal)
#library(rCharts)
library(leafletR)


INPUT="Toolkit_geocoded_Honduras.csv"

GADM_Aggregation = "Honduras_1990-2013.shp"


wd = "C:\\Scratch"
setwd(wd) 

data_dir = "C:\\GDrive\\AidData\\Decision_Support\\Main\\data"

sector=vector()
sector[1] = "water"
sector[2] = "enviro"
sector[3] = "transport|highway|road"

sector_names = vector()
sector_names[1] = "Water-Related Projects"
sector_names[2] = "Environmental Projects"
sector_names[3] = "Infrastructure Projects"

#Create overlays for sectors.
for (i in 1:length(sector))
  {
  input_data = read.csv(INPUT, header=TRUE)
  sector_data <- input_data[grep(sector[i], input_data$LOCATION_ACTIVITY_DESCRIPTION),]
  sector_data["TITLE"] = as.data.frame(apply(sector_data["TITLE"],2,function(x)gsub("[^0-9A-Za-z///' ]", "", x)))
  geocoded_sector_data <- sector_data[rowSums(is.na(sector_data[,c("LATITUDE","LONGITUDE")]))==0,]
  GIS_sector_data <- SpatialPointsDataFrame(list(geocoded_sector_data$LONGITUDE,geocoded_sector_data$LATITUDE), sector_data)
  GIS_sector_data <- GIS_sector_data[,c('TITLE','LATITUDE','LONGITUDE','DONOR')]

  proj4string(GIS_sector_data) <- CRS("+init=epsg:4326")
  toGeoJSON(data=GIS_sector_data, name=sector_names[i], dest=data_dir) 
  }


#Create ancilliary data layers
GIS_GADM = readShapePoly(GADM_Aggregation)

GIS_GADM <- GIS_GADM[,c('ADM2_NAME')]

#Raster Aggregations

#Population Density (roughly per sq. km)
Rlayer <- raster("2011ls_hond.tif")
Attribute_GIS <- extract(Rlayer,GIS_GADM, fun='mean', na.rm=TRUE, sp=TRUE, small=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("X2011ls_hond" = "POP_DENSITY"))

#Droughts in the past? 1980-2001 (binary)
Rlayer <- raster("dr_events.tif")
Attribute_GIS <- extract(Rlayer,Attribute_GIS, fun='max', na.rm=FALSE, sp=TRUE, small=TRUE, weights=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("dr_events" = "HISTORIC_DROUGHT_EVENTS"))

#Distance to roads
Rlayer <- raster("dist_road.tif")
Attribute_GIS <- extract(Rlayer,Attribute_GIS, fun='mean', na.rm=TRUE, sp=TRUE, weights=TRUE, small=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("dist_road" = "DISTANCE_TO_MAJOR_ROADS"))

#Distance to cities
Rlayer <- raster("dist_city.tif")
Attribute_GIS <- extract(Rlayer,Attribute_GIS, fun='mean', na.rm=TRUE, sp=TRUE, weights=TRUE, small=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("dist_city" = "DISTANCE_TO_NEAREST_CITY"))

#Rice yield potential
Rlayer <- raster("res02_crav6190l_l021_000_yld.tif")
Attribute_GIS <- extract(Rlayer,Attribute_GIS, fun='mean', na.rm=TRUE, sp=TRUE, small=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("res02_crav6190l_l021_000_yld" = "AG_YIELD_POTENTIAL_RICE"))

#NDVI
Rlayer <- raster("ca4114.tif")
Attribute_GIS <- extract(Rlayer,Attribute_GIS, fun='mean', na.rm=TRUE, sp=TRUE, small=TRUE)
Attribute_GIS <- rename(Attribute_GIS, c("ca4114" = "NDVI"))

proj4string(Attribute_GIS) <- CRS("+init=epsg:4326")

#Threats to human water security (higher is worse - http://www.viewsoftheworld.net/?p=896)
Rlayer <- raster("WaterSecurity.tif")

Attribute_GIS@data$WaterSecurity = NA

for (i in 1:nrow(Attribute_GIS))
{
  Attribute_GIS@data$WaterSecurity[i] = extract(Rlayer,Attribute_GIS[i,], na.rm=TRUE, small=TRUE, method="bilinear", buffer=.10, weights=TRUE, fun="MEAN")
}


toGeoJSON(data=Attribute_GIS, dest=data_dir)

#Create a visualizaion of our data.


# cuts<-round(quantile(Attribute_GIS$POP_DENSITY, probs = seq(0,1,0.2), na.rm = TRUE),0)
# cuts[1] <- 0
# 
# popup <- c("ADM2_NAME", "POP_DENSITY")
# 
# sty<- styleGrad(prop="POP_DENSITY", breaks=cuts, right=FALSE, style.par="col",
#                 style.val=rev(heat.colors(6)), leg="Population Density per sq. KM (2011)", lwd=1)
# 
# popdens <- toGeoJSON(data=Attribute_GIS, dest=tempdir())
# 
# map<-leaflet(data=popdens, style=sty,
#              title="index", base.map="osm",
#              incl.data=TRUE,  popup=popup)
# 
# #browseURL(map)

DTD <- merge(Attribute_GIS, project_data)
DTD$dr_events[is.na(DTD$dr_events)] <- 0

DTD_C <- DTD[complete.cases(DTD$Freq),]

fit <- rpart(Above_med_projects ~ POP_DENSITY + dr_events + dist_road + dist_city + WS, data=DTD_C)

plotcp(fit)
plot(fit, uniform=TRUE, main="Classificaiton Tree for Water-related Aid")
text(fit, use.n=TRUE, all=TRUE, cex=.8)
post(fit, file="c:\\Scratch\\tree.ps", title="Classification Tree for Water-related Aid in Honduras")

Attribute_GIS$DT_EST <- predict(fit, newdata = Attribute_GIS)

cuts<-round(quantile(Attribute_GIS$DT_EST, probs = seq(0.0,1.0,0.2), na.rm = TRUE),2)
cuts[1] <- 0

popup <- c("ADM2_NAME", "DT_EST")

#sty<- styleGrad(prop="DT_EST", breaks=cuts, right=FALSE, style.par="col",style.val=rev(heat.colors(6)), leg="Probability of >avg Water projects", lwd=1)
# sty <- styleGrad(prop="DT_EST", breaks=cuts, style.val=rev(heat.colors(6)))
# sty_2 <- styleGrad(prop="dist_road", breaks=cuts, style.val=rev(heat.colors(6)))
# 
# sty <- styleSingle(col="brown")
# sty_2 <- styleSingle(col="red")
# 

# 
#  map<-leaflet(data=AtrGeo, style=sty_2,
#               title="index_2", incl.data=TRUE)
# # 
# map<-leaflet(data=list(AtrGeo,AtrGeo), style=list(sty,sty_2),
#              title="index_2", incl.data=TRUE)
# # 
#  browseURL(map)


AtrGeo <- toGeoJSON(data=Attribute_GIS, dest=tempdir())